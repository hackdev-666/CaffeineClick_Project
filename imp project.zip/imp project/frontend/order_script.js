document.addEventListener('DOMContentLoaded', () => {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    const cartSlide = document.getElementById('cart-slide');
    const cartIcon = document.getElementById('cart-icon');
    const cartItemsList = document.querySelector('.cart-items');
    const totalElement = document.querySelector('.total');

    const modal = document.getElementById('user-info-modal');
    const form = document.getElementById('user-info-form');
    const closeModal = document.querySelector('.close-modal');
    const cancelButton = document.getElementById('cancel-modal');

    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    function addToCart(name, price) {
        cart.push({ name, price });
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCart();
    }

    function updateCart() {
        cartItemsList.innerHTML = '';
        let totalPrice = 0;

        cart.forEach((item, index) => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `${item.name} - ₹${item.price} <span class="remove-item" data-index="${index}">❌</span>`;
            cartItemsList.appendChild(listItem);
            totalPrice += item.price;
        });

        totalElement.textContent = `Total: ₹${totalPrice}`;

        document.querySelectorAll('.remove-item').forEach(button => {
            button.addEventListener('click', () => {
                const indexToRemove = parseInt(button.dataset.index);
                cart.splice(indexToRemove, 1);
                localStorage.setItem('cart', JSON.stringify(cart));
                updateCart();
            });
        });
    }

    addToCartButtons.forEach(button => {
        button.addEventListener('click', () => {
            const name = button.dataset.name;
            const price = parseInt(button.dataset.price);
            addToCart(name, price);
        });
    });

    if (cartIcon) {
        cartIcon.addEventListener('click', (event) => {
            event.preventDefault();
            cartSlide.classList.toggle('show');
        });
    }

    placeOrderButton.addEventListener('click', () => {
        if (cart.length === 0) {
            alert('Your cart is empty!');
        } else {
            modal.style.display = 'block';
        }
    });

    closeModal.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    cancelButton.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const address = document.getElementById('address').value;

        if (!name || !address) {
            alert('Please fill in all fields.');
            return;
        }

        // You would now typically send the cart data and user info to your backend here
        console.log('Ready to send order:', { name, address, cart });
        alert('Order details ready to be sent!'); 
    });

    updateCart();
});